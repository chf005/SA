# forms.py
from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import AnimalInventory, Animals    

class UserRegisterForm(UserCreationForm):
    email = forms.EmailField()

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

class AnimalQuantityChangeForm(forms.ModelForm):
    REASON_CHOICES = [
        ('', '請選擇原因'),
        ('birth', '新生'),
        ('purchase', '購買'),
        ('death', '死亡'),
        ('sale', '售出'),
        ('other', '其他'),
    ]
    
    change_reason = forms.ChoiceField(choices=REASON_CHOICES, label='變動原因')
    other_reason = forms.CharField(max_length=100, required=False, label='其他原因說明')
    
    class Meta:
        model = AnimalInventory
        fields = ['animal_id', 'quantity_change', 'change_reason']
        labels = {
            'animal_id': '動物種類',
            'quantity_change': '數量變動',
        }
        widgets = {
            'quantity_change': forms.NumberInput(attrs={'min': '1'}),
        }
        
    def clean(self):
        cleaned_data = super().clean()
        reason = cleaned_data.get('change_reason')
        other_reason = cleaned_data.get('other_reason')
        
        if reason == 'other' and not other_reason:
            self.add_error('other_reason', '選擇其他原因時，請提供說明')
        
        if reason == 'other' and other_reason:
            cleaned_data['change_reason'] = other_reason
            
        return cleaned_data