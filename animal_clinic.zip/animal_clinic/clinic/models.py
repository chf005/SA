
from django.db import models
from django.utils import timezone   

class Sales(models.Model):
    order_id = models.AutoField(primary_key=True)
    order_date = models.DateField()
    customer = models.CharField(max_length=100)
    phone = models.CharField(max_length=20)
    delivery_date = models.DateField()
    address = models.TextField()
    total_price = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"Order {self.order_id}"


class Animals(models.Model):
    animal_id = models.CharField(primary_key=True, max_length=20)
    species = models.CharField(max_length=50)
    breed = models.CharField(max_length=50)
    birth_date = models.DateField()
    gender = models.CharField(max_length=10)
    order_id = models.ForeignKey('sales', on_delete=models.SET_NULL, null=True, db_column='order_id')
    
    class Meta:
        db_table = 'animals'
        
    def get_current_quantity(self):
        from django.db.models import Sum
        total = AnimalInventory.objects.filter(animal_id=self.animal_id).aggregate(Sum('quantity_change'))
        return total['quantity_change__sum'] or 0
    
class AnimalInventory(models.Model):
    inventory_id = models.AutoField(primary_key=True)
    animal_id = models.ForeignKey('animals', on_delete=models.CASCADE, db_column='animal_id')
    quantity_change = models.IntegerField()  # 正數為增加，負數為減少
    change_date = models.DateTimeField(default=timezone.now)
    change_reason = models.CharField(max_length=100)  # 例如：新生、購買、死亡、售出等
    
    class Meta:
        db_table = 'animal_inventory'
        
    def __str__(self):
        return f"{self.animal_id} - {self.change_date} - {self.quantity_change}"


class MedicalRecord(models.Model):
    animal = models.ForeignKey(Animals, on_delete=models.CASCADE)
    diagnosis = models.TextField()
    treatment = models.TextField()
    cured = models.BooleanField(default=False)
    visit_date = models.DateField()

    def __str__(self):
        return f"Record {self.record_id} for {self.animal.animal_id}"
