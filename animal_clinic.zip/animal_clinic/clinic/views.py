# views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Sum

from animal_clinic.forms import UserRegisterForm
from .models import Animals, AnimalInventory
from .forms import AnimalQuantityChangeForm

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'帳號已創建，您現在可以登入了！')
            return redirect('login')
    else:
        form = UserRegisterForm()
    return render(request, 'users/register.html', {'form': form})
def home(request):
    # 您的首頁視圖邏輯
    return redirect('admin:index')  # 重定向到管理員頁面

@login_required
def animal_quantity_list(request):
    """顯示所有動物的當前數量"""
    animals = Animals.objects.all()
    
    # 計算每種動物的當前數量
    animal_quantities = []
    for animal in animals:
        total_quantity = AnimalInventory.objects.filter(animal_id=animal.animal_id).aggregate(Sum('quantity_change'))
        current_quantity = total_quantity['quantity_change__sum'] or 0
        
        animal_quantities.append({
            'animal': animal,
            'quantity': current_quantity
        })
    
    return render(request, 'animal_quantity_list.html', {
        'animal_quantities': animal_quantities
    })

@login_required
def add_animal_quantity(request):
    """增加動物數量"""
    if request.method == 'POST':
        form = AnimalQuantityChangeForm(request.POST)
        if form.is_valid():
            inventory = form.save(commit=False)
            # 確保數量變化為正數
            if inventory.quantity_change <= 0:
                messages.error(request, '新增數量必須大於0')
            else:
                inventory.save()
                messages.success(request, f'成功新增 {inventory.quantity_change} 隻 {inventory.animal_id.species} {inventory.animal_id.breed}')
                return redirect('animal_quantity_list')
    else:
        form = AnimalQuantityChangeForm(initial={'quantity_change': 1})
    
    return render(request, 'animal_quantity_form.html', {
        'form': form,
        'action': '新增數量',
    })

@login_required
def reduce_animal_quantity(request):
    """減少動物數量"""
    if request.method == 'POST':
        form = AnimalQuantityChangeForm(request.POST)
        if form.is_valid():
            inventory = form.save(commit=False)
            # 轉換為負數表示減少
            inventory.quantity_change = -abs(inventory.quantity_change)
            
            # 檢查是否會導致數量小於0
            animal = inventory.animal_id
            current_quantity = AnimalInventory.objects.filter(animal_id=animal.animal_id).aggregate(Sum('quantity_change'))
            current_quantity = current_quantity['quantity_change__sum'] or 0
            
            if current_quantity + inventory.quantity_change < 0:
                messages.error(request, f'減少數量後總數會小於0。當前數量: {current_quantity}')
            else:
                inventory.save()
                messages.success(request, f'成功減少 {abs(inventory.quantity_change)} 隻 {inventory.animal_id.species} {inventory.animal_id.breed}')
                return redirect('animal_quantity_list')
    else:
        form = AnimalQuantityChangeForm(initial={'quantity_change': 1})
    
    return render(request, 'animal_quantity_form.html', {
        'form': form,
        'action': '減少數量',
    })

@login_required
def animal_quantity_history(request, animal_id):
    """顯示特定動物的數量變動歷史"""
    animal = get_object_or_404(Animals, animal_id=animal_id)
    history = AnimalInventory.objects.filter(animal_id=animal_id).order_by('-change_date')
    
    return render(request, 'animal_quantity_history.html', {
        'animal': animal,
        'history': history,
    })