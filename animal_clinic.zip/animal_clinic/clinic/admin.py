from django.contrib import admin
from .models import Sales, Animal, MedicalRecord

admin.site.register(Sales)
admin.site.register(Animal)
admin.site.register(MedicalRecord)
